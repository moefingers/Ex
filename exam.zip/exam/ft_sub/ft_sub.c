int ft_sub(int *ptr, int nbr)
{
	*ptr = *ptr - nbr;
}
